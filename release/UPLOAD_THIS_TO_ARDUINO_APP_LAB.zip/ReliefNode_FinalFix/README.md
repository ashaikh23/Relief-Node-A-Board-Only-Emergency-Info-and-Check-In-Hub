# Relief Node — Climate + On-Device GenAI UI Refresh

Arduino UNO Q 4GB App Lab project for a local emergency information, climate logging, community check-in, and on-device generative-AI response hub.

## What this build includes

- Local emergency notice board and community check-ins.
- SQLite persistence for notices, check-ins, climate snapshots, and cached NWS alerts.
- Open-Meteo weather logging plus U.S. National Weather Service active alerts.
- UNO Q LED matrix/RGB status feedback through Bridge.
- Local Qwen 3.5 0.8B Q4_0 summarization and translation through `arduino:llm`.
- Deterministic offline action-card fallback if the local model cannot run.
- Human approval before any AI-generated emergency text can be published.
- Needs clustering for help, medical, water, food, shelter, power, transport, and supplies.
- Host-side `RELIEF-NODE` Wi-Fi hotspot scripts.

## UI improvements in this build

- Clean safety/energy visual system based on Pico CSS v2 design conventions, with a complete local fallback stylesheet so the page remains styled offline.
- Verified **Admin mode** indicator in the header. Enter the organizer PIN and press Unlock (or finish typing the PIN); the backend verifies it before the browser displays Admin mode. Privileged actions still validate the PIN independently.
- Full interface translations for English, Spanish, Arabic, Hindi, and French, including controls, climate labels, status labels, weather-condition labels, summaries, and dashboard headings.
- The on-device AI translation target is a real dropdown with 21 common languages. The underlying Qwen model supports additional languages, but the dropdown is intentionally curated for a predictable contest UI.
- Every displayed timestamp now includes the browser's local timezone abbreviation when supported (for example `Sep 13, 11:42 AM PDT`).
- Right-to-left layout is enabled automatically for Arabic.

> The selected UI language now translates the full interface **and the currently published Relief Node notice** using the local LLM. Notice translations are cached locally while the original source notice remains unchanged. NWS source text and user-entered names/notes remain verbatim.

## Local model language coverage

The UI ships with five hand-reviewed interface languages. Static interface text switches instantly; the currently published notice is translated on-device and cached when a non-English UI language is selected. The organizer's **Translate draft** control uses a curated dropdown of common target languages.

## First run

1. Import this ZIP into Arduino App Lab.
2. Press **Run**.
3. If App Lab asks for the model, download **Qwen 3.5 0.8B Q4_0** once.
4. Open the Network URL shown by WebUI.
5. Default organizer PIN: `2468`.
6. Change `ADMIN_PIN` in `python/main.py` before a public demo.

## Admin mode

The header only displays **Admin mode** after the backend has verified the PIN. The indicator can be clicked to lock the browser again and clear the PIN field. This indicator is only a UI state: every sensitive backend operation still checks the submitted PIN.

## Climate logging

Configure a location under **Climate settings** using latitude/longitude or the phone-location helper. When internet is available, Relief Node records current weather and active NWS alerts. The last successful snapshot stays available locally if the internet disappears.

## AI safety flow

`verified source notice -> local LLM draft -> organizer review -> Approve & publish`

The model is a communication assistant, not an emergency authority. It never publishes directly and does not determine whether an evacuation or official alert is valid.

## Standalone hotspot

From the UNO Q host shell:

```bash
cd ~/ArduinoApps/<your-app-folder>
sudo ./host_tools/setup_relief_hotspot.sh
```

See `host_tools/README.md` for details.


## Board status behavior

- **SAFE:** large matrix check mark; all four RGB LEDs are green.
- **ALERT:** large single exclamation mark; all four RGB LEDs are amber.
- **EMERGENCY:** matrix shows `!!!`; all four RGB LEDs blink red.
- **HELP request:** temporary H/! matrix pattern; all four RGB LEDs pulse magenta, then return to the prior board mode.

UNO Q LEDs 1-2 are controlled from the Linux/MPU side and LEDs 3-4 from the MCU sketch, matching Arduino's official four-LED example architecture.
